package com.github.android.lvrn.lvrnproject.util;

/**
 * @author Vadim Boitsov <vadimboitsov1@gmail.com>
 */

public final class CurrentState {

    public static String profileId;

}
